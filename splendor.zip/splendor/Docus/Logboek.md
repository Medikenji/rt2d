# Logboek Splendor

## Nolan Bijmholt

---

### Disclaimer

Ik begin vanaf nu (06-12-23) een nieuwe manier van een logboek maken omdat mij het makkelijker lijkt om een logboek bij te houden in het programma waar ik in werk. Ook vind ik markdown verassend fijn en leuk om te gebruiken. Hierdoor lijkt mij het makkelijker om mijn taken op te schrijven en code te presenteren.
Ik heb op dit punt al een groot deel van mijn klassen klaar dus het maken van de volgende klassen zal niet genoemd worden maar wel in gewerkt worden.

- gamescene
- player
- enemy
- altpathenemy
- linepath enemy

Ik zal een werkstructuur aannemen waarin ik fouten opschrijf en bijhoud als nummers. Dit doe ik omdat ik dan kan bijhouden hoeveel probleem ik heb gekregen en de structuur van nummers ziet er mooi uit.

---

> #### 07/12/23

Ik ben van plan het eerste uur mijn documentatie klaar te zetten en mijn folders goed te organiseren. Dit document is hier onder andere het resultaat van.
Ik heb in het 2e uur een spawner functie gemaakt om een bepaalde hoeveelheid enemies te creeëren op willekeurige posities.
In 3e uur ga ik een nieuw enemy type maken, dit type beweegt niet. Ik heb de altPathEnemy ook een nieuwe AI gegeven om zijn tactiek constant te veranderen.

---

# Week 50

---

> #### 11/12/23

Ik ben de hele dag bezig geweest om mijn portfolio op nieuw te maken. Dit is volledig gelukt behalve het hosten in verband met niet betaald geld.

> #### 12/12/23

Ik heb het spel aangepast door altpathenemy een nieuwe functie te geven. Ook heeft de speler nu collision met de enemies.

> #### 13/12/23

Ik heb de muis laten verdwijnen in mijn spel. Ook heb ik een werkend health systeem gemaakt voor de speler met een game over state.
